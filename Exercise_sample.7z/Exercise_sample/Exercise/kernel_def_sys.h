/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_def_sys.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_DEF_SYS_H
#define _HIOS_KERNEL_DEF_SYS_H

/****************************************************************************/
/*	Other definition														*/
/****************************************************************************/
#define hi_copspt	  USE		/* coprocessor function(Always USE)			*/
#define hi_hook		  NOTUSE	/* hook routine function					*/
#if ((hi_def_inh) == USE | (hi_def_exc) == USE)
	#define hi_vctcpy	  USE		/* vector copy function					*/
#else
	#define hi_vctcpy	  NOTUSE	/* vector copy function					*/
#endif
#if ((hi_vdef_trp) == USE)
	#define hi_trpcpy	  USE		/* trap copy function					*/
#else
	#define hi_trpcpy	  NOTUSE	/* trap copy function					*/
#endif
/****************************************************************************/
/*	Define cb_xxx for XXXCB and XXXCB routine								*/
/****************************************************************************/
#ifdef hi_name
	#undef hi_name
#endif

#define hi_name NOTUSE

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_tim for TIMCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if \
		( (hi_tslp_tsk)  | \
		  (hi_twai_flg)  | \
		  (hi_twai_sem)  | \
		  (hi_trcv_mbx)  | \
		  (hi_tsnd_mbf)  | \
		  (hi_trcv_mbf)  | \
		  (hi_tget_mpl)  | \
		  (hi_tget_mpf)  | \
		  (hi_vtwai_tfl) | \
		  (hi_dly_tsk)   | \
		  (hi_tsnd_dtq)  | \
		  (hi_trcv_dtq)  | \
		  (hi_tloc_mtx)  | \
		  (hi_get_tim)   | \
		  (hi_set_tim)   | \
		  (hi_cre_cyc)   | \
		  (hi_acre_cyc)  | \
		  (hi_del_cyc)   | \
		  (hi_sta_cyc)   | \
		  (hi_stp_cyc)   | \
		  (hi_ref_cyc)   | \
		  (hi_cre_alm)   | \
		  (hi_acre_alm)  | \
		  (hi_del_alm)   | \
		  (hi_sta_alm)   | \
		  (hi_stp_alm)   | \
		  (hi_ref_alm)   | \
		  (hi_def_ovr)   | \
		  (hi_sta_ovr)   | \
		  (hi_stp_ovr)   | \
		  (hi_ref_ovr)   | \
		  (hi_isig_tim) )
	 #define cb_tim USE
#else
	 #define cb_tim NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_tmout for qu/dq_tim module link			 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if \
		( (hi_tslp_tsk)  | \
		  (hi_twai_flg)  | \
		  (hi_twai_sem)  | \
		  (hi_trcv_mbx)  | \
		  (hi_tsnd_mbf)  | \
		  (hi_trcv_mbf)  | \
		  (hi_tget_mpl)  | \
		  (hi_tget_mpf)  | \
		  (hi_vtwai_tfl) | \
		  (hi_dly_tsk)   | \
		  (hi_tsnd_dtq)  | \
		  (hi_trcv_dtq)  | \
		  (hi_tloc_mtx) )
	 #define cb_tmout USE
#else
	 #define cb_tmout NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_tfl for TFLCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if \
		( (hi_vset_tfl) | \
		  (hi_vclr_tfl) | \
		  (hi_vwai_tfl) | \
		  (hi_vpol_tfl) | \
		  (hi_vtwai_tfl))
	 #define cb_tfl USE
#else
	 #define cb_tfl NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_sem for SEMCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_sem) | (hi_acre_sem) )
	 #define cb_sem USE
#else
	 #define cb_sem NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_flg for FLGCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_flg) | (hi_acre_flg) )
	 #define cb_flg USE
#else
	 #define cb_flg NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_mbx for MBXCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_mbx) | (hi_acre_mbx) )
	 #define cb_mbx USE
#else
	 #define cb_mbx NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_mbf for MBFCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_mbf) | (hi_acre_mbf) )
	 #define cb_mbf USE
#else
	 #define cb_mbf NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_mpl for MPLCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_mpl) | (hi_acre_mpl) )
	 #define cb_mpl USE
#else
	 #define cb_mpl NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_mpf for MPFCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_mpf) | (hi_acre_mpf) )
	 #define cb_mpf USE
#else
	 #define cb_mpf NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_cyc for CYHCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_cyc) | (hi_acre_cyc) )
	 #define cb_cyc USE
#else
	 #define cb_cyc NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_alm for ALHCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_alm) | (hi_acre_alm) )
	 #define cb_alm USE
#else
	 #define cb_alm NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_svc for SVCCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_def_svc) | (hi_cal_svc) )
	 #define cb_svc USE
#else
	 #define cb_svc NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_ovr for TSKOVRCB						 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if \
		( (hi_def_ovr)  | \
		  (hi_sta_ovr)  | \
		  (hi_stp_ovr)  | \
		  (hi_ref_ovr) )
	 #define cb_ovr USE
#else
	 #define cb_ovr NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_mtx for MTXCB, TLMXCB					 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_mtx) | (hi_acre_mtx) )
	 #define cb_mtx USE
#else
	 #define cb_mtx NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_dtq for DTQCB1,2,						 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if ( (hi_cre_dtq) | (hi_acre_dtq) )
	 #define cb_dtq USE
#else
	 #define cb_dtq NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_tex for TEXCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if \
		( (hi_def_tex)  | \
		  (hi_ras_tex)  | \
		  (hi_dis_tex)  | \
		  (hi_ena_tex)  | \
		  (hi_sns_tex)  | \
		  (hi_ref_tex)  )
	 #define cb_tex USE
#else
	 #define cb_tex NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_cac for CACCB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if \
		( (hi_vini_cac)  | \
		  (hi_vclr_cac)  | \
		  (hi_vfls_cac)  | \
		  (hi_vinv_cac)  )
	 #define cb_cac USE
#else
	 #define cb_cac NOTUSE
#endif

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_trace for TBACB							 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#define cb_trace USE

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* definition for reserved functions			 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/

  /*+++++++++++++++++++++++++++++++++++++++++++++*/
  /* cb_name??? for NAME???CB					 */
  /*+++++++++++++++++++++++++++++++++++++++++++++*/
#if (hi_name)
	 #define cb_nametsk USE

	 #if (cb_sem)
		  #define cb_namesem USE
	 #else
		  #define cb_namesem NOTUSE
	 #endif

	 #if (cb_flg)
		  #define cb_nameflg USE
	 #else
		  #define cb_nameflg NOTUSE
	 #endif

	 #if (cb_mbx)
		  #define cb_namembx USE
	 #else
		  #define cb_namembx NOTUSE
	 #endif

	 #if (cb_mbf)
		  #define cb_namembf USE
	 #else
		  #define cb_namembf NOTUSE
	 #endif

	 #if (cb_mpl)
		  #define cb_namempl USE
	 #else
		  #define cb_namempl NOTUSE
	 #endif

	 #if (cb_mpf)
		  #define cb_namempf USE
	 #else
		  #define cb_namempf NOTUSE
	 #endif

	 #if (cb_cyc)
		  #define cb_namecyc USE
	 #else
		  #define cb_namecyc NOTUSE
	 #endif

	 #if (cb_alm)
		  #define cb_namealm USE
	 #else
		  #define cb_namealm NOTUSE
	 #endif

#else
	 #define cb_nametsk NOTUSE
	 #define cb_namesem NOTUSE
	 #define cb_nameflg NOTUSE
	 #define cb_namembx NOTUSE
	 #define cb_namembf NOTUSE
	 #define cb_namempl NOTUSE
	 #define cb_namempf NOTUSE
	 #define cb_namecyc NOTUSE
	 #define cb_namealm NOTUSE

#endif

/* Optimized timer driver ***************************************************/
#ifdef OPTTMR
//     #include "kernel_def_opttmr.h"
#endif

/* DSP standby management ***************************************************/
#ifdef DSPSTBY
//     #include "kernel_def_dspstby.h"
     #define hi_vchg_cop USE
#else
     #define hi_vchg_cop NOTUSE
#endif

#endif
