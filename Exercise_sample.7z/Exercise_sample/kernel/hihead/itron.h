/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : itron.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef __HIOS_ITRON_H
#define __HIOS_ITRON_H

/****************************************************************************/
/*							   type definition								*/
/****************************************************************************/
#pragma pack 4

typedef signed char		B;				/* signed 8 bit integer				*/
typedef signed short	H;				/* signed 16 bit integer			*/
typedef signed long		W;				/* signed 32 bit integer			*/

typedef unsigned char	UB;				/* unsigned 8 bit integer			*/
typedef unsigned short	UH;				/* unsigned 16 bit integer			*/
typedef unsigned long	UW;				/* unsigned 32 bit integer			*/

typedef B				VB;				/* variable data type (8 bit)		*/
typedef H				VH;				/* variable data type (16 bit)		*/
typedef W				VW;				/* variable data type (32 bit)		*/

typedef void			*VP;			/* pointer to variable data type	*/
typedef void			(*FP)(void);	/* program start address			*/

typedef int				INT;			/* signed integer (CPU dependent)	*/
typedef unsigned int	UINT;			/* unsigned integer (CPU dependent) */

typedef INT				BOOL;			/* Bool value						*/

typedef W				FN;				/* function code					*/
typedef W				ER;				/* error code						*/
typedef H				ID;				/* object ID (xxxid)				*/
typedef UW				ATR;			/* attribute						*/
typedef UW				STAT;			/* object status					*/
typedef UW				MODE;			/* action mode						*/
typedef H				PRI;			/* task priority					*/
typedef UW				SIZE;			/* memory area size					*/

typedef W				TMO;			/* time out							*/
typedef UW				RELTIM;			/* relative time					*/

typedef struct {						/* system clock						*/
			UH			utime;			/* current date/time (upper)		*/
/***		VH			_Hrsv;				   reserved					  ***/
			UW			ltime;			/* current date/time (lower)		*/
		} SYSTIM;

typedef INT				VP_INT;			/* integer or pointer to var. data	*/

typedef ER				ER_BOOL;		/* error code or bool value			*/
typedef ER				ER_ID;			/* error code or object ID			*/
typedef ER				ER_UINT;		/* error code or unsigned integer	*/

#pragma unpack
/****************************************************************************/
/*							   fixed number									*/
/****************************************************************************/
/*--------------------------------- whole ----------------------------------*/
#ifndef  NULL
    #ifdef  __cplusplus
        #define  NULL           0UL
    #else
        #define  NULL           ((void *)0)
    #endif
#endif
#ifdef NULL
    #ifdef _HIOS_CONFIGURATOR
        #undef NULL
    #endif
#endif
#define TRUE			1				/* true								*/
#define FALSE			0				/* false							*/
#define E_OK			0L				/* normal end						*/

/****************************************************************************/
/*			Service call error code (Main error code)						*/
/****************************************************************************/
/*---- internal error class ----*/
#define E_SYS			(-5L)			/* system error						*/

/*---- no support error class ----*/
#define E_NOSPT			(-9L)			/* no support function				*/
#define E_RSFN			(-10L)			/* reserved function code number	*/
#define E_RSATR			(-11L)			/* reserved attribute code number	*/

/*---- parameter error class ----*/
#define E_PAR			(-17L)			/* parameter error					*/
#define E_ID			(-18L)			/* reserved id number				*/

/*---- context error class ----*/
#define E_CTX			(-25L)			/* context error					*/
#define E_MACV			(-26L)			/* memory access violation			*/
#define E_OACV			(-27L)			/* object access violation			*/
#define E_ILUSE			(-28L)			/* service call illegal use			*/

/*---- resource insufficiency error class ----*/
#define E_NOMEM			(-33L)			/* no memory						*/
#define E_NOID			(-34L)			/* no ID							*/

/*---- object status error class ----*/
#define E_OBJ			(-41L)			/* object status error				*/
#define E_NOEXS			(-42L)			/* object non existent				*/
#define E_QOVR			(-43L)			/* queuing over flow				*/

/*---- wait release error class ----*/
#define E_RLWAI			(-49L)			/* wait status forced release		*/
#define E_TMOUT			(-50L)			/* time out							*/
#define E_DLT			(-51L)			/* delete object					*/
#define E_CLS			(-52L)			/* status change of wait object		*/

/*---- warning class ----*/
#define E_WBLK			(-57L)			/* non blocking receipt				*/
#define E_BOVR			(-58L)			/* buffer over flow					*/

/****************************************************************************/
/*								 fixed number								*/
/****************************************************************************/
/*---- object attribute ----*/
#define TA_NULL			0UL				/* no object attribute specify		*/

/*---- time out specify ----*/
#define TMO_POL			0L				/* polling							*/
#define TMO_FEVR		(-1L)			/* forever wait						*/
#define TMO_NBLK		(-2L)			/* non blocking						*/

/****************************************************************************/
/*								  macro										*/
/****************************************************************************/
/*---- error code acquirement ----*/
#define MERCD(ercd) ((ER)((B)(ercd)))

#define SERCD(ercd) ((ercd) >> 8)

#endif
