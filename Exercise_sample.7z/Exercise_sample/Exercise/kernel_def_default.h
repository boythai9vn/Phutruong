/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_def_default.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_DEF_DEFAULT_H
#define _HIOS_KERNEL_DEF_DEFAULT_H

/****************************************************************************/
/*	Define hi_???? which are not defined by kernel_def_main.h				*/
/****************************************************************************/
#ifndef hi_parchk
#define hi_parchk USE
#endif

#ifndef hi_debug
#define hi_debug NO_TRACE
#endif

#ifndef hi_isig_tim
#define hi_isig_tim USE
#endif

#ifndef hi_maxvctno
#define hi_maxvctno 0xfe0
#endif

#ifndef hi_maxtrpno
#define hi_maxtrpnp 255
#endif

#ifndef hi_sr_dsp
#define hi_sr_dsp 0x00000000
#endif

/*** Task management						***********/

#ifndef	hi_cre_tsk
	#define	hi_cre_tsk	USE
#endif
#ifndef	hi_acre_tsk
	#define	hi_acre_tsk	USE
#endif
#ifndef	hi_vscr_tsk
	#define	hi_vscr_tsk	USE
#endif
#ifndef	hi_del_tsk
	#define	hi_del_tsk	USE
#endif
#ifndef	hi_act_tsk
	#define	hi_act_tsk	USE
#endif
#ifndef	hi_can_act
	#define	hi_can_act	USE
#endif
#ifndef	hi_sta_tsk
	#define	hi_sta_tsk	USE
#endif
#ifndef	hi_ext_tsk
	#define	hi_ext_tsk	USE
#endif
#ifndef	hi_exd_tsk
	#define	hi_exd_tsk	USE
#endif
#ifndef	hi_ter_tsk
	#define	hi_ter_tsk	USE
#endif
#ifndef	hi_chg_pri
	#define	hi_chg_pri	USE
#endif
#ifndef	hi_get_pri
	#define	hi_get_pri	USE
#endif
#ifndef	hi_ref_tsk
	#define	hi_ref_tsk	USE
#endif
#ifndef	hi_ref_tst
	#define	hi_ref_tst	USE
#endif
#ifndef	hi_vchg_tmd
	#define	hi_vchg_tmd	USE
#endif

/*** Task-dependent synchronization			***********/

#ifndef	hi_slp_tsk
	#define	hi_slp_tsk	USE
#endif
#ifndef	hi_tslp_tsk
	#define	hi_tslp_tsk	USE
#endif
#ifndef	hi_wup_tsk
	#define	hi_wup_tsk	USE
#endif
#ifndef	hi_can_wup
	#define	hi_can_wup	USE
#endif
#ifndef	hi_rel_wai
	#define	hi_rel_wai	USE
#endif
#ifndef	hi_sus_tsk
	#define	hi_sus_tsk	USE
#endif
#ifndef	hi_rsm_tsk
	#define	hi_rsm_tsk	USE
#endif
#ifndef	hi_frsm_tsk
	#define	hi_frsm_tsk	USE
#endif
#ifndef	hi_dly_tsk
	#define	hi_dly_tsk	USE
#endif
#ifndef	hi_vset_tfl
	#define	hi_vset_tfl	USE
#endif
#ifndef	hi_vclr_tfl
	#define	hi_vclr_tfl	USE
#endif
#ifndef	hi_vwai_tfl
	#define	hi_vwai_tfl	USE
#endif
#ifndef	hi_vpol_tfl
	#define	hi_vpol_tfl	USE
#endif
#ifndef	hi_vtwai_tfl
	#define	hi_vtwai_tfl	USE
#endif

/*** Task exception process					***********/

#ifndef	hi_def_tex
	#define	hi_def_tex	USE
#endif
#ifndef	hi_ras_tex
	#define	hi_ras_tex	USE
#endif
#ifndef	hi_dis_tex
	#define	hi_dis_tex	USE
#endif
#ifndef	hi_ena_tex
	#define	hi_ena_tex	USE
#endif
#ifndef	hi_sns_tex
	#define	hi_sns_tex	USE
#endif
#ifndef	hi_ref_tex
	#define	hi_ref_tex	USE
#endif

/*** Synchronization and communication		***********/

	/*** Semaphore			  *************/

#ifndef	hi_cre_sem
	#define	hi_cre_sem	USE
#endif
#ifndef	hi_acre_sem
	#define	hi_acre_sem	USE
#endif
#ifndef	hi_del_sem
	#define	hi_del_sem	USE
#endif
#ifndef	hi_sig_sem
	#define	hi_sig_sem	USE
#endif
#ifndef	hi_wai_sem
	#define	hi_wai_sem	USE
#endif
#ifndef	hi_pol_sem
	#define	hi_pol_sem	USE
#endif
#ifndef	hi_twai_sem
	#define	hi_twai_sem	USE
#endif
#ifndef	hi_ref_sem
	#define	hi_ref_sem	USE
#endif

	/*** Eventflag			  *************/

#ifndef	hi_cre_flg
	#define	hi_cre_flg	USE
#endif
#ifndef	hi_acre_flg
	#define	hi_acre_flg	USE
#endif
#ifndef	hi_del_flg
	#define	hi_del_flg	USE
#endif
#ifndef	hi_set_flg
	#define	hi_set_flg	USE
#endif
#ifndef	hi_clr_flg
	#define	hi_clr_flg	USE
#endif
#ifndef	hi_wai_flg
	#define	hi_wai_flg	USE
#endif
#ifndef	hi_pol_flg
	#define	hi_pol_flg	USE
#endif
#ifndef	hi_twai_flg
	#define	hi_twai_flg	USE
#endif
#ifndef	hi_ref_flg
	#define	hi_ref_flg	USE
#endif

	/*** Data queue			  *************/

#ifndef	hi_cre_dtq
	#define	hi_cre_dtq	USE
#endif
#ifndef	hi_acre_dtq
	#define	hi_acre_dtq	USE
#endif
#ifndef	hi_del_dtq
	#define	hi_del_dtq	USE
#endif
#ifndef	hi_snd_dtq
	#define	hi_snd_dtq	USE
#endif
#ifndef	hi_psnd_dtq
	#define	hi_psnd_dtq	USE
#endif
#ifndef	hi_tsnd_dtq
	#define	hi_tsnd_dtq	USE
#endif
#ifndef	hi_fsnd_dtq
	#define	hi_fsnd_dtq	USE
#endif
#ifndef	hi_rcv_dtq
	#define	hi_rcv_dtq	USE
#endif
#ifndef	hi_prcv_dtq
	#define	hi_prcv_dtq	USE
#endif
#ifndef	hi_trcv_dtq
	#define	hi_trcv_dtq	USE
#endif
#ifndef	hi_ref_dtq
	#define	hi_ref_dtq	USE
#endif

	/*** Mailbox			  *************/

#ifndef	hi_cre_mbx
	#define	hi_cre_mbx	USE
#endif
#ifndef	hi_acre_mbx
	#define	hi_acre_mbx	USE
#endif
#ifndef	hi_del_mbx
	#define	hi_del_mbx	USE
#endif
#ifndef	hi_snd_mbx
	#define	hi_snd_mbx	USE
#endif
#ifndef	hi_rcv_mbx
	#define	hi_rcv_mbx	USE
#endif
#ifndef	hi_prcv_mbx
	#define	hi_prcv_mbx	USE
#endif
#ifndef	hi_trcv_mbx
	#define	hi_trcv_mbx	USE
#endif
#ifndef	hi_ref_mbx
	#define	hi_ref_mbx	USE
#endif

	/*** Mutex				  *************/

#ifndef	hi_cre_mtx
	#define	hi_cre_mtx	USE
#endif
#ifndef	hi_acre_mtx
	#define	hi_acre_mtx	USE
#endif
#ifndef	hi_del_mtx
	#define	hi_del_mtx	USE
#endif
#ifndef	hi_loc_mtx
	#define	hi_loc_mtx	USE
#endif
#ifndef	hi_ploc_mtx
	#define	hi_ploc_mtx	USE
#endif
#ifndef	hi_tloc_mtx
	#define	hi_tloc_mtx	USE
#endif
#ifndef	hi_unl_mtx
	#define	hi_unl_mtx	USE
#endif
#ifndef	hi_ref_mtx
	#define	hi_ref_mtx	USE
#endif

	/*** Message buffer		  *************/

#ifndef	hi_cre_mbf
	#define	hi_cre_mbf	USE
#endif
#ifndef	hi_acre_mbf
	#define	hi_acre_mbf	USE
#endif
#ifndef	hi_del_mbf
	#define	hi_del_mbf	USE
#endif
#ifndef	hi_snd_mbf
	#define	hi_snd_mbf	USE
#endif
#ifndef	hi_psnd_mbf
	#define	hi_psnd_mbf	USE
#endif
#ifndef	hi_tsnd_mbf
	#define	hi_tsnd_mbf	USE
#endif
#ifndef	hi_rcv_mbf
	#define	hi_rcv_mbf	USE
#endif
#ifndef	hi_prcv_mbf
	#define	hi_prcv_mbf	USE
#endif
#ifndef	hi_trcv_mbf
	#define	hi_trcv_mbf	USE
#endif
#ifndef	hi_ref_mbf
	#define	hi_ref_mbf	USE
#endif

/*** Memorypool management					***********/

	/*** Fixed-size			  *************/

#ifndef	hi_cre_mpf
	#define	hi_cre_mpf	USE
#endif
#ifndef	hi_acre_mpf
	#define	hi_acre_mpf	USE
#endif
#ifndef	hi_del_mpf
	#define	hi_del_mpf	USE
#endif
#ifndef	hi_get_mpf
	#define	hi_get_mpf	USE
#endif
#ifndef	hi_pget_mpf
	#define	hi_pget_mpf	USE
#endif
#ifndef	hi_tget_mpf
	#define	hi_tget_mpf	USE
#endif
#ifndef	hi_rel_mpf
	#define	hi_rel_mpf	USE
#endif
#ifndef	hi_ref_mpf
	#define	hi_ref_mpf	USE
#endif

	/*** Variable-size		  *************/

#ifndef	hi_cre_mpl
	#define	hi_cre_mpl	USE
#endif
#ifndef	hi_acre_mpl
	#define	hi_acre_mpl	USE
#endif
#ifndef	hi_del_mpl
	#define	hi_del_mpl	USE
#endif
#ifndef	hi_get_mpl
	#define	hi_get_mpl	USE
#endif
#ifndef	hi_pget_mpl
	#define	hi_pget_mpl	USE
#endif
#ifndef	hi_tget_mpl
	#define	hi_tget_mpl	USE
#endif
#ifndef	hi_rel_mpl
	#define	hi_rel_mpl	USE
#endif
#ifndef	hi_ref_mpl
	#define	hi_ref_mpl	USE
#endif

/*** Timer management						***********/

	/*** System time management ***********/

#ifndef	hi_set_tim
	#define	hi_set_tim	USE
#endif
#ifndef	hi_get_tim
	#define	hi_get_tim	USE
#endif

	/*** Cyclic handler		  *************/

#ifndef	hi_cre_cyc
	#define	hi_cre_cyc	USE
#endif
#ifndef	hi_acre_cyc
	#define	hi_acre_cyc	USE
#endif
#ifndef	hi_del_cyc
	#define	hi_del_cyc	USE
#endif
#ifndef	hi_sta_cyc
	#define	hi_sta_cyc	USE
#endif
#ifndef	hi_stp_cyc
	#define	hi_stp_cyc	USE
#endif
#ifndef	hi_ref_cyc
	#define	hi_ref_cyc	USE
#endif

	/*** Alarm handler		  *************/

#ifndef	hi_cre_alm
	#define	hi_cre_alm	USE
#endif
#ifndef	hi_acre_alm
	#define	hi_acre_alm	USE
#endif
#ifndef	hi_del_alm
	#define	hi_del_alm	USE
#endif
#ifndef	hi_sta_alm
	#define	hi_sta_alm	USE
#endif
#ifndef	hi_stp_alm
	#define	hi_stp_alm	USE
#endif
#ifndef	hi_ref_alm
	#define	hi_ref_alm	USE
#endif

	/*** Overrun handler	  *************/

#ifndef	hi_def_ovr
	#define	hi_def_ovr	USE
#endif
#ifndef	hi_sta_ovr
	#define	hi_sta_ovr	USE
#endif
#ifndef	hi_stp_ovr
	#define	hi_stp_ovr	USE
#endif
#ifndef	hi_ref_ovr
	#define	hi_ref_ovr	USE
#endif

/*** System status management				***********/

#ifndef	hi_rot_rdq
	#define	hi_rot_rdq	USE
#endif
#ifndef	hi_get_tid
	#define	hi_get_tid	USE
#endif
#ifndef	hi_loc_cpu
	#define	hi_loc_cpu	USE
#endif
#ifndef	hi_unl_cpu
	#define	hi_unl_cpu	USE
#endif
#ifndef	hi_dis_dsp
	#define	hi_dis_dsp	USE
#endif
#ifndef	hi_ena_dsp
	#define	hi_ena_dsp	USE
#endif
#ifndef	hi_sns_ctx
	#define	hi_sns_ctx	USE
#endif
#ifndef	hi_sns_loc
	#define	hi_sns_loc	USE
#endif
#ifndef	hi_sns_dsp
	#define	hi_sns_dsp	USE
#endif
#ifndef	hi_sns_dpn
	#define	hi_sns_dpn	USE
#endif
#ifndef	hi_vsys_dwn
	#define	hi_vsys_dwn	USE
#endif
#ifndef	hi_vget_trc
	#define	hi_vget_trc	USE
#endif
#ifndef	hi_ivbgn_int
	#define	hi_ivbgn_int	USE
#endif
#ifndef	hi_ivend_int
	#define	hi_ivend_int	USE
#endif

/*** Interrupt management					***********/

#ifndef	hi_def_inh
	#define	hi_def_inh	USE
#endif
#ifndef	hi_chg_ims
	#define	hi_chg_ims	USE
#endif
#ifndef	hi_get_ims
	#define	hi_get_ims	USE
#endif

/*** Service call management				***********/

#ifndef	hi_def_svc
	#define	hi_def_svc	USE
#endif
#ifndef	hi_cal_svc
	#define	hi_cal_svc	USE
#endif

/*** System construction management			***********/

#ifndef	hi_def_exc
	#define	hi_def_exc	USE
#endif
#ifndef	hi_vdef_trp
	#define	hi_vdef_trp	USE
#endif
#ifndef	hi_ref_cfg
	#define	hi_ref_cfg	USE
#endif
#ifndef	hi_ref_ver
	#define	hi_ref_ver	USE
#endif

/*** Cache management						***********/

#ifndef	hi_vclr_cac
	#define	hi_vclr_cac	USE
#endif
#ifndef	hi_vfls_cac
	#define	hi_vfls_cac	USE
#endif
#ifndef	hi_vinv_cac
	#define	hi_vinv_cac	USE
#endif
#ifndef	hi_vini_cac
	#define	hi_vini_cac	USE
#endif

/****************************************************************************/
/*	Define hi_ixxx_yyy														*/
/****************************************************************************/
/*** Task management						***********/

#define		hi_icre_tsk	hi_cre_tsk
#define		hi_iacre_tsk	hi_acre_tsk
#define		hi_ivscr_tsk	hi_vscr_tsk
#define		hi_iact_tsk	hi_act_tsk
#define		hi_ican_act	hi_can_act
#define		hi_ista_tsk	hi_sta_tsk
#define		hi_ichg_pri	hi_chg_pri
#define		hi_iget_pri	hi_get_pri
#define		hi_iref_tsk	hi_ref_tsk
#define		hi_iref_tst	hi_ref_tst

/*** Task-dependent synchronization			***********/

#define		hi_iwup_tsk	hi_wup_tsk
#define		hi_ican_wup	hi_can_wup
#define		hi_irel_wai	hi_rel_wai
#define		hi_isus_tsk	hi_sus_tsk
#define		hi_irsm_tsk	hi_rsm_tsk
#define		hi_ifrsm_tsk	hi_frsm_tsk
#define		hi_ivset_tfl	hi_vset_tfl
#define		hi_ivclr_tfl	hi_vclr_tfl

/*** Task exception process					***********/

#define		hi_idef_tex	hi_def_tex
#define		hi_iras_tex	hi_ras_tex
#define		hi_iref_tex	hi_ref_tex

/*** Synchronization and communication		***********/

#define		hi_icre_sem	hi_cre_sem
#define		hi_iacre_sem	hi_acre_sem
#define		hi_isig_sem	hi_sig_sem
#define		hi_ipol_sem	hi_pol_sem
#define		hi_iref_sem	hi_ref_sem

#define		hi_icre_flg	hi_cre_flg
#define		hi_iacre_flg	hi_acre_flg
#define		hi_iset_flg	hi_set_flg
#define		hi_iclr_flg	hi_clr_flg
#define		hi_ipol_flg	hi_pol_flg
#define		hi_iref_flg	hi_ref_flg

#define		hi_icre_dtq	hi_cre_dtq
#define		hi_iacre_dtq	hi_acre_dtq
#define		hi_ipsnd_dtq	hi_psnd_dtq
#define		hi_ifsnd_dtq	hi_fsnd_dtq
#define		hi_iprcv_dtq	hi_prcv_dtq
#define		hi_iref_dtq	hi_ref_dtq

#define		hi_icre_mbx	hi_cre_mbx
#define		hi_iacre_mbx	hi_acre_mbx
#define		hi_isnd_mbx	hi_snd_mbx
#define		hi_iprcv_mbx	hi_prcv_mbx
#define		hi_iref_mbx	hi_ref_mbx

#define		hi_icre_mbf	hi_cre_mbf
#define		hi_iacre_mbf	hi_acre_mbf
#define		hi_ipsnd_mbf	hi_psnd_mbf
#define		hi_iprcv_mbf	hi_prcv_mbf
#define		hi_iref_mbf	hi_ref_mbf

/*** Memorypool management					***********/

#define		hi_icre_mpf	hi_cre_mpf
#define		hi_iacre_mpf	hi_acre_mpf
#define		hi_ipget_mpf	hi_pget_mpf
#define		hi_irel_mpf	hi_rel_mpf
#define		hi_iref_mpf	hi_ref_mpf

#define		hi_icre_mpl	hi_cre_mpl
#define		hi_iacre_mpl	hi_acre_mpl
#define		hi_ipget_mpl	hi_pget_mpl
#define		hi_irel_mpl	hi_rel_mpl
#define		hi_iref_mpl	hi_ref_mpl

/*** Timer management						***********/

#define		hi_iset_tim	hi_set_tim
#define		hi_iget_tim	hi_get_tim

#define		hi_icre_cyc	hi_cre_cyc
#define		hi_iacre_cyc	hi_acre_cyc
#define		hi_ista_cyc	hi_sta_cyc
#define		hi_istp_cyc	hi_stp_cyc
#define		hi_iref_cyc	hi_ref_cyc

#define		hi_icre_alm	hi_cre_alm
#define		hi_iacre_alm	hi_acre_alm
#define		hi_ista_alm	hi_sta_alm
#define		hi_istp_alm	hi_stp_alm
#define		hi_iref_alm	hi_ref_alm

#define		hi_idef_ovr	hi_def_ovr
#define		hi_ista_ovr	hi_sta_ovr
#define		hi_istp_ovr	hi_stp_ovr
#define		hi_iref_ovr	hi_ref_ovr

/*** System status management				***********/

#define		hi_irot_rdq	hi_rot_rdq
#define		hi_iget_tid	hi_get_tid
#define		hi_iloc_cpu	hi_loc_cpu
#define		hi_iunl_cpu	hi_unl_cpu
#define		hi_ivsys_dwn	hi_vsys_dwn
#define		hi_ivget_trc	hi_vget_trc

/*** Interrupt management					***********/

#define		hi_idef_inh	hi_def_inh
#define		hi_ichg_ims	hi_chg_ims
#define		hi_iget_ims	hi_get_ims

/*** Service call management				***********/

#define		hi_idef_svc	hi_def_svc
#define		hi_ical_svc	hi_cal_svc

/*** System construction management			***********/

#define		hi_idef_exc	hi_def_exc
#define		hi_ivdef_trp	hi_vdef_trp
#define		hi_iref_cfg	hi_ref_cfg
#define		hi_iref_ver	hi_ref_ver

/*** Cache management						***********/

#define		hi_ivclr_cac	hi_vclr_cac
#define		hi_ivfls_cac	hi_vfls_cac
#define		hi_ivinv_cac	hi_vinv_cac
#define		hi_ivini_cac	hi_vini_cac

#define	hi_ret_int	USE

/*	for DX Action										*/
#if ((hi_debug) & ACTION) != 0
	 #undef	 hi_parchk
	 #undef	 hi_cre_cyc
	 #define hi_parchk	USE
	 #define hi_cre_cyc USE

	 #if ((hi_debug)&(TARGET_TRACE|EML_TRACE)) != 0
		#define hi_dact_trc USE
	 #else
		#define hi_dact_trc NOTUSE
	 #endif

	 #define hi_ddel_tsk USE
	 #define hi_dsus_tsk USE
	 #define hi_dter_tsk USE
#else
	 #define hi_dact_trc NOTUSE
	 #define hi_ddel_tsk NOTUSE
	 #define hi_dsus_tsk NOTUSE
	 #define hi_dter_tsk NOTUSE

#endif

#endif
