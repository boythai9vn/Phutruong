#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Local variable */
struct mychar {
	char chars[10];
};
/* Ending declare local variable*/

/* Declare Prototype */
void introduceSW();
void ReadInput(mychar a[], int n);
void WriteOutput(mychar a[], int n);
int  Sum(mychar a[], int n);
int  Mindiff(mychar a[], int n);
int  Locate(mychar a[], int n);
int  Error_num(int n, int i);
int  Error_type(char strNum[]);
int  Error_size(int n);
/* Ending Declare Prototype */

/* Main Program	*/
void main()
{
	introduceSW();
	struct mychar a[10];
	int n, i;
	int j = 1;
	do {
		printf("Input number of total elements into series!\n");
		printf("This number must be > 0 and < 11: ");
		scanf("%d", &n);
		j = Error_size(n);
	} while (j == 1);
	while (getchar() != '\n');
	ReadInput(a, n);
	WriteOutput(a, n);
	int sum = Sum(a, n);
	int mindiff = Mindiff(a, n);
	int c = Locate(a, n);
	printf("Sum is               :  %d\n", sum);
	printf("Mindiff is           :  %d\n", mindiff, "\n");
	printf("Mindiff position at  :  %d\n", c);
	getch();
}

/* =============================================== Defind Functions ====================================================== */
/*
Introduction
*/
void introduceSW() {
	char *intro;
	intro = "1. Read input (a series of positive integer number) from keyboard, \n   maximum 10 numbers.\n   Input format: 1 2 3 4 5 6 7 8 9 10\n2. SW determine the sum of all inputs.\n3. SW determine the minimum difference between 2 sub-groups of this series,\nnumbers in each sub-group must be consecutive.\n4. SW determine the number at which the above minimum difference is reached.\n===============================================================================";
	puts(intro);
}

/*
Read Input data
*/
void ReadInput(struct mychar a[], int n)
{
	int i;
	/* Type Input series number */
	do {
		printf("Type your series number: ");
		for (i = 0; i<n; i++) {
			scanf("%s", &a[i].chars);
			if (getchar() == '\n') {
				if (Error_num(n, i) == 1) {
					printf("\t\t< ========================================== >\n");
					printf("\t\t         Not enough value. Do Again!\n");
					printf("\t\t< ========================================== >\n");
					break;
				}
				else {
					for (i = 0; i<n; i++) {
						if (Error_type(a[i].chars) == 1) {
							i = 99;
							printf("\t\t< ========================================== >\n");
							printf("\t\t     Input data is wrong type. Do Again!\n");
							printf("\t\t< ========================================== >\n");
							break;
						}
						else {
							if (atol(a[i].chars) > 20000) {
								i = 99;
								printf("\t\t< ========================================== >\n");
								printf("\t\t     Input data is over load. Do Again!\n");
								printf("\t\t< ========================================== >\n");
								break;
							}
						};
					}
				}
			}
			if (i == 99) {
				i = 0;
				break;
			}
		}
	} while (i <= (n - 1));
}

/*
Display data of array
*/
void WriteOutput(mychar a[], int n) {
	/* In day so */
	printf("Your series number is:\t");
	for (int i = 0; i < n; i++) {
		printf("%s\t", a[i].chars);
	}
	printf("\n");
}

/*
Check enough value for all element?
*/
int Error_num(int n, int i) {
	if (i < (n - 1)) {
		return 1;
	}
	return 0;
}

/*
Check input data type is a number?
*/
int Error_type(char strNum[]) {
	int error = 0;
	int i = 0;
	while (i <= (strlen(strNum) - 1) && error == 0) {
		if ((strNum[i] >= '0') && (strNum[i] <= '9')) {
			error = 0;
		}
		else {
			error = 1;
			break;
		}
		i = i + 1;
	}
	return error;
}

/*
Check size of series number have to < 11 numbers
*/
int  Error_size(int n) {
	if (!(n > 0 && n < 11)) {
		printf("\t\t< ========================================== >\n");
		printf("\t\t   Number must be a unsigned integer number!\n");
		printf("\t\t< ========================================== >\n");
		return 1;
	}
	return 0;
}

/*
Calculate sum of all elements of series number input
*/
int Sum(mychar a[], int n)
{
	int i;
	int sum = 0;
	for (i = 0; i<n; i++)
	{
		sum = sum + atol(a[i].chars);
	}
	return sum;
}

/*
Find minumum of the sub of two different sub-series number.
*/
int Mindiff(mychar a[], int n)
{
	int sum = Sum(a, n);
	int i;
	int j = (-1);
	int b[10];
	int sum1 = 0;
	for (i = 0; i<n; i++)
	{
		sum1 = sum1 + atol(a[i].chars);
		j++;
		b[j] = abs(sum - (2 * sum1));
	}
	int result = b[0];
	for (i = 1; i<j; i++)
	{
		if (result >= b[i])
			result = b[i];
	}
	return result;
}

/*
Display position make minimum Mindiff
*/
int Locate(mychar a[], int n)
{
	int sum = Sum(a, n);
	int x = Mindiff(a, n);
	int i;
	int j = 0;
	int b[10];
	int sum1 = 0;
	for (i = 0; i<n; i++)
	{
		sum1 = sum1 + atol(a[i].chars);
		b[j] = abs(sum - (2 * sum1));
		j++;
	}
	for (int i = 0; i < j; i++) {
		if (x == b[i])
			return (i + 1);
	}
	return 10;
}


/*=============================================== Ending Defind Functions =============================================== */