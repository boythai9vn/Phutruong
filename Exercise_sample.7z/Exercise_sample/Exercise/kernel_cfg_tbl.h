/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_cfg_tbl.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_CFG_TBL_H
#define _HIOS_KERNEL_CFG_TBL_H

#pragma pack 4
/****************************************************************************/
/*			INITSP (ROM/hienv)												*/
/****************************************************************************/
typedef struct	initsp	{
		VP		su_initspl;				/* task stack limit address			*/
		VP		su_initspb;				/* task stack bottom address		*/
} INITSP;

#define _INI_STATIC_STK(top,size) \
					 (VP)top, \
					 (VP)(((VW *)top)+size/sizeof(VW)-2),

/****************************************************************************/
/*			INITRC (ROM/hienv)												*/
/****************************************************************************/
typedef struct	initrc	{
		VP		su_trbtop;				/* top address of trace buffer		*/
		UW		su_trbcnt;				/* number of trace entry			*/
} INITRC;

/****************************************************************************/
/*			RDYPRI (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	rdypri	{
		UW		tp_rdypri[8];			/* READY bitmap(tskpri=0...255)		*/
} RDYPRI;

/****************************************************************************/
/*			RDYQUE (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	rdyque	{
		VP		rq_nexttcb;				/* Next pointer						*/
		VP		rq_pretcb;				/* Previous pointer					*/
} RDYQUE;

/****************************************************************************/
/*			TCB (RAM/hiwrk)													*/
/****************************************************************************/
typedef struct	tcb	 {
		void	*tc_nexttcb;			/* Next pointer						*/
		void	*tc_pretcb;				/* Previous pointer					*/
		UB		tc_rststs;				/* Context restore status			*/
		UB		tc_itskpri;				/* Initial tskpri					*/
		PRI		tc_ctskpri;				/* Current tskpri					*/
		UW		tc_ctsksts;				/* Task status						*/
		void	*tc_rdyquep;			/* Ready queue pointer				*/
		void	*tc_rdyprip;			/* Ready pri pointer				*/
		UW		tc_priptn;				/* Priority bit pattern				*/
		void	*tc_ctsksp;				/* Current SP(Context saved address)*/
		void	*tc_tmqntcb;			/* Next pointer(timer queue)		*/
		void	*tc_tmqptcb;			/* Previous pointer(timer queue)	*/
		TMO		tc_wlftime;				/* Left time count					*/
		void	*tc_wobjid;				/* Wait-object CB					*/
		UB		tc_pndsts;				/* Pending status of create			*/
		UB		tc_actcnt;				/* Activation count					*/
		UB		tc_bpri;				/* Base priority					*/
		UB		tc_pndptn;				/* Mask pattern, Pending pattern	*/
		VP		tc_splimit;				/* Stack limit address(top)			*/
		FP		tc_istadr;				/* Task start address(task)			*/
		VP		tc_exinf;				/* Extended information(exinf)		*/
} TCB;

/****************************************************************************/
/*			STKQUE (RAM/histstk)											*/
/****************************************************************************/
typedef struct	stkcb  {
		TCB		*stk_nexttcb;			/* Next pointer(stack queue)		*/
		TCB		*stk_pretcb;			/* Previous pointer(stack queue)	*/
} STKQUE;

/****************************************************************************/
/*			TFLCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	tflcb  {
		UINT	tf_flgptn;				/* Task eventflag pattern			*/
} TFLCB;

/****************************************************************************/
/*			FLGCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	flgcb	{
		TCB		*ec_nexttcb;			/* Next pointer						*/
		TCB		*ec_pretcb;				/* Previous pointer					*/
		UINT	ec_flgdat;				/* Eventflag pattern				*/
		UW		ec_quests;				/* Queue status						*/
} FLGCB;

/****************************************************************************/
/*			SEMCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	semcb	{
		TCB		*sc_nexttcb;			/* Next pointer						*/
		union {
			TCB	   *sc_pretcb;			/* Previous pointer					*/
			UINT   semcnt;				/* Semaphore count					*/
		} uni_semcb;
		UINT	sc_maxsemcnt;			/* Maximum semcnt					*/
		UW		sc_quests;				/* Queue status						*/
} SEMCB;

/****************************************************************************/
/*			MBXCB1 (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mbxcb1	 {
		VP		mb_nextadr;				/* Next message/TCB address			*/
		VP		mb_preadr;				/* Previous message/TCB address		*/
		PRI		mb_maxmpri;				/* Maximum message priority			*/
		UH		mb_rsv;					/* Reserved							*/
		UW		mb_quests;				/* Queue status						*/
} MBXCB1;

/****************************************************************************/
/*			MBXCB2 (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mbxcb2	 {
		UB		mb_mbxsts;				/* Mailbox queue status				*/
} MBXCB2;

/****************************************************************************/
/*			MBFCB1 (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mbfcb1	{
		TCB		*bf_nexttcb;			/* Next pointer						*/
		TCB		*bf_pretcb;				/* Previous pointer					*/
		VP		bf_mbftop;				/* Messagebuffer top address		*/
		VP		bf_mbflast;				/* Messagebuffer bottom address		*/
		VP		bf_msgrp;				/* Message read pointer				*/
		VP		bf_msgwp;				/* Message write pointer			*/
		UINT	bf_maxmsz;				/* Maximum message size				*/
		UINT	bf_bufsz;				/* Messagebuffer size				*/
		UINT	bf_smsgcnt;				/* Message counter in buffer		*/
		UW		bf_quests;				/* Queue status						*/
} MBFCB1;

/****************************************************************************/
/*			MBFCB2 (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mbfcb2	 {
		UB		bf_bufsts;				/* Messagebuffer queue status		*/
} MBFCB2;

/****************************************************************************/
/*			MSGSZCB (RAM/hiwrk(Message buffer))								*/
/****************************************************************************/
typedef struct	msgszcb	 {
		VP		bf_msgsz;				/* Message size						*/
} MSGSZCB;

/****************************************************************************/
/*			MPLCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mplcb	{
		TCB		*mp_nexttcb;			/* Next pointer						*/
		TCB		*mp_pretcb;				/* Previous pointer					*/
		union {
			VP	   mp_mpltop;			/* Memorypool top address			*/
			VP	   mp_frbtop;			/* First free block top address		*/
		} uni_mplcb;
		VP		mp_frblast;				/* Last free block top address		*/
		INT		mp_mplsz;				/* Memorypool size					*/
		VP		mp_exinf;				/* Reserved							*/
		UW		mp_quests;				/* Queue status						*/
} MPLCB;

/****************************************************************************/
/*			MBLKCB (RAM/himpl)												*/
/****************************************************************************/
typedef struct	mblkcb	{
		VP		mp_nextadr;				/* Next MBLKCB address				*/
		VP		mp_preadr;				/* Previous MBLKCB address			*/
		UINT	mp_usesiz;				/* Using block size					*/
		UINT	mp_fresiz;				/* Free block size					*/
} MBLKCB;

/*******************************************
 * VBLKCB[VARIABLE : Resource]
 *******************************************/
typedef struct _vblkcb{    
		struct _vblkcb *vbk_nextadr;	/* Next address queue pointer		*/
		struct _vblkcb *vbk_preadr; 	/* Previous address queue pointer	*/
		VP		*vbk_next;				/* Next free/use queue pointer		*/
		VP		*vbk_pre;				/* Previous free/use queue pointer	*/
		UW		vbk_size;				/* Block size						*/
		UW		vbk_type;				/* Block type						*/
		VP		vbk_blkadr; 			/* Block top address				*/
		VP		*vbk_sctcbp;			/* SCTCB pointer					*/
} VBLKCB;

/*******************************************
 * FRBQUE [VARIABLE : Structure definition]
 *******************************************/
typedef struct {    
		VBLKCB	*fr_next;				/* Next pointer 					*/
		VBLKCB	*fr_pre;				/* Previous pointer 				*/
} FRBQUE;

/*******************************************
 * USBQUE [VARIABLE : Structure definition]
 *******************************************/
typedef struct {    
		VBLKCB	*us_next;				/* Next pointer 					*/
		VBLKCB	*us_pre;				/* Previous pointer 				*/
} USBQUE;

/*******************************************
 * SCTCB [VARIABLE : Structure definition]
 *******************************************/
typedef struct _sctcb { 
		struct _sctcb *st_sctqnext; 	/* Next pointer 					*/
		struct _sctcb *st_sctqpre;		/* Previous pointer 				*/
		UW		st_bitmap;				/* Free/Use block bit map			*/
		VP		*st_blkcbp; 			/* VBLKCB address					*/
		UW		st_sctbsz;				/* Sector block size				*/
		UW		st_fuluse;				/* Block full used bitmap pattern	*/
} SCTCB;

/*******************************************
 * FRSQUE [VARIABLE : Structure definition]
 *******************************************/
typedef struct {    
		SCTCB	*sq_frqnextp;			/* Next pointer 					*/
		SCTCB	*sq_frqprep;			/* Previous pointer 				*/
} FRSQUE;

/*******************************************
 * USSQUE [VARIABLE : Structure definition]
 *******************************************/
typedef struct {    
		SCTCB	*sq_usqnextp;			/* Next pointer 					*/
		SCTCB	*sq_usqprep;			/* Previous pointer 				*/
} USSQUE;

/*******************************************
 * SCTQUE [VARIABLE : Structure definition]
 *******************************************/
typedef struct {    
		USSQUE	sq_useq[4]; 			/* Used sector queue				*/
		FRSQUE	sq_freq;				/* Free sector queue				*/
} SCTQUE;

/*******************************************
 * VMPLCB [VARIABLE : cfg-static]
 *******************************************/
typedef struct {    
		TCB 	*vmp_nexttcb;			/* Next pointer 					*/
		TCB 	*vmp_pretcb; 			/* Previous pointer 				*/
		VBLKCB	*vmp_nextadr;			/* Next VBLKCB						*/
		VBLKCB	*vmp_preadr;			/* Previous VBLKCB					*/
		VP		vmp_mpltop; 			/* Memorypool top address			*/
		INT 	vmp_mplsz;				/* Memorypool size					*/
		UW		vmp_quests; 			/* Queue status 					*/
		UW		vmp_frqbssz;			/* Free block queuing base size 	*/
		UW		vmp_ftotalsz;			/* Free total size					*/
		UW		vmp_minblksz;			/* Minimum block size				*/
		SCTQUE	*vmp_sctquep;			/* SCTQUE address					*/
		FRBQUE	vmp_frbque[8];			/* Free block queue 				*/
		USBQUE	vmp_usbque[8];			/* Used block queue 				*/
} VMPLCB;

/****************************************************************************/
/*			MPFCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mpfcb	{
		TCB		*mf_nexttcb;			/* Next pointer						*/
		TCB		*mf_pretcb;				/* Previous pointer					*/
		VP		mf_mpltop;				/* Memorypool top address			*/
		VP		mf_mpllast;				/* Memorypool bottom address		*/
		VP		mf_frbtop;				/* First free block top address		*/
		VP		mf_frblast;				/* Last free block top address		*/
		INT		mf_frbcnt;				/* Free block counts				*/
		INT		mf_blksz;				/* Block size						*/
		VP		mf_blkhtop;				/* MPFHCB top address				*/
		UW		mf_quests;				/* Queue status						*/
} MPFCB;

/****************************************************************************/
/*			MBLFCB (RAM/himpl)												*/
/****************************************************************************/
typedef struct	mblfcb	{
		VP		mf_nextadr;				/* Next MBLFCB address				*/
} MBLFCB;

/****************************************************************************/
/*			  MPFHCB (RAM/himpl)											*/
/****************************************************************************/
typedef struct	  mpfhcb	{
		VP		  mf_nextadr;				 /* Next MBLFCB address			*/
} MPFHCB;

/****************************************************************************/
/*			FLGATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	flgatcb	  {
		UB		ec_flgatr;				/* Eventflag attribute				*/
} FLGATCB;

/****************************************************************************/
/*			SEMATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	sematcb {
		UB		sc_sematr;				/* Semaphore attribute				*/
} SEMATCB;

/****************************************************************************/
/*			MBXATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mbxatcb {
		UB		mb_mbxatr;				/* Mailbox attribute				*/
} MBXATCB;

/****************************************************************************/
/*			MBFATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mbfatcb {
		UB		bf_mbfatr;				/* Messagebuffer attribute			*/
} MBFATCB;

/****************************************************************************/
/*			MPLATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mplatcb {
		UB		mp_mplatr;				/* Var-size memorypool attribute	*/
} MPLATCB;

/****************************************************************************/
/*			MPFATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mpfatcb {
		UB		mf_mpfatr;				/* Fix-size memorypool attribute	*/
} MPFATCB;


/****************************************************************************/
/*			CYHCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	cyhcb	{
		VP		ch_nextcyc;				/* Next pointer						*/
		VP		ch_precyc;				/* Previous pointer					*/
		UH		ch_cycact;				/* Cyclic handler activation		*/
		UH		ch_cycatr;				/* Cyclic handler attribute			*/
		RELTIM	ch_lftime;				/* Left time						*/
		RELTIM	ch_cyctim;				/* Cyclic time						*/
		FP		ch_cychdr;				/* Cyclic handler start address		*/
		VP_INT	ch_exinf;				/* Extended information				*/
		UW		ch_quests;				/* Queue status						*/
} CYHCB;

/****************************************************************************/
/*          CYHCB2 (RAM/hiwrk)                                              */
/****************************************************************************/
typedef struct  cyhcb2   {
		W		ch2_carrytim;			/* Carried time						*/
		UW		ch2_isigque;			/* Queing status in isig_tim		*/
} CYHCB2;

/****************************************************************************/
/*			ALHCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	alhcb	{
		VP		ah_nextalm;				/* Next pointer						*/
		VP		ah_prealm;				/* Previous pointer					*/
		ID		ah_almno;				/* Alarm handler No(ID)				*/
		UH		ah_almact;				/* Alarm handler activation			*/
		RELTIM	ah_llftime;				/* Left time						*/
		FP		ah_almhdr;				/* Alarm handler start address		*/
		VP_INT	ah_exinf;				/* Extended information				*/
		UW		ah_quests;				/* Queue status						*/
} ALHCB;

/****************************************************************************/
/*			TIMCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	timcb	{
		TCB		*tm_nexttcb;			/* Next pointer (TCB)				*/
		TCB		*tm_pretcb;				/* Previous pointer (TCB)			*/
		CYHCB	*tm_nextcyc;			/* Next pointer (CYHCB)				*/
		CYHCB	*tm_precyc;				/* Previous pointer (CYHCB)			*/
		ALHCB	*tm_nextalm;			/* Next pointer (ALHCB)				*/
		ALHCB	*tm_prealm;				/* Previous pointer (ALHCB)			*/
		UW		tm_ltime;				/* System time(lower)				*/
		H		tm_utime;				/* System time(upper)				*/
		UH		tm_quests;				/* Timer queue status				*/
		UW		tm_decini;				/* Optimized timer interval initial	*/
		UW		tm_dectim;				/* Optimized timer queue remain		*/
} TIMCB;

/****************************************************************************/
/*			SVCCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	svccb	{
		FP		sv_svchdr;				/* Ex-SVC handler start address		*/
} SVCCB;

/****************************************************************************/
/*			TBACB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	tbacb	{
		VP		ta_trbadr;				/* Trace buffer address				*/
} TBACB;

/****************************************************************************/
/*			SYSCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	syscb	{
		TCB		*sy_ctcbp;				/* Current TCB address				*/
		TMO		sy_timqantm;			/* Current task's time quantum		*/
		UB		sy_tswflg;				/* Dispatching request flag			*/
		UB		sy_kexcnt;				/* Reserved							*/
		UB		sy_hookflg;				/* Trace hooking flag				*/
		UB		sy_ctskims;				/* Reserved							*/
		TCB		*sy_nexttcb;			/* Next dispatching TCB address		*/
		W		sy_maxpri;				/* Current highest priority			*/
		UH		sy_syssts;				/* Reserved							*/
		ID		sy_copid;				/* Task id which use coprocessor	*/
		VP		sy_dispadr;				/* Dispatch address					*/
		VP		sy_dispadr_sw;			/* Dispatch_sw address				*/
		UW		sy_irqcnt;				/* IRQ nest count					*/
		UW		sy_locsr;				/* SR of INDP for iloc_cpu			*/
} SYSCB;
/****************************************************************************/
/*			VCTCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	vctcb	{
		VP		vc_intvctp;		/* interrupt vector top address				*/
		VP		vc_trpvctp;		/* trapa	 vector top address				*/
} VCTCB;

/****************************************************************************/
/*			TSKATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	tskatcb {
		UB		tc_tskatr;		/* coprocessor data in tskatr				*/
} TSKATCB;

/****************************************************************************/
/*			TEXCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	texcb	{
		FP		tx_texrtn;				/* Task exception routine addresss	*/
		UW		tx_texptn;				/* Task exception pending pattern	*/
		UH		tx_texstat;				/* Task exception routine status	*/
		UH		tx_texsts;				/* Task exception routine running	*/
		VP		tx_texsp;				/* TEX context frame address		*/
} TEXCB;

/****************************************************************************/
/*			TEXATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	texatcb {
		UB		tx_texatr;		/* coprocessor data in texatr				*/
} TEXATCB;

/****************************************************************************/
/*			DTQCB1 (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	dtqcb1	{
		TCB		*dt_nexttcb;			/* Next pointer						*/
		TCB		*dt_pretcb;				/* Previous pointer					*/
		VP		dt_dtqtop;				/* Data queue area top address		*/
		VP		dt_dtqlast;				/* Data queue area last address		*/
		VP		dt_dtqsndp;				/* Data write pointer				*/
		VP		dt_dtqrcvp;				/* Data read pointer				*/
		UINT	dt_dtqcnt;				/* Data counter in data queue		*/
		UINT	dt_maxdtqcnt;			/* Maximum data count of self		*/
		UW		dt_quests;				/* Queue status						*/
} DTQCB1;

/****************************************************************************/
/*			DTQCB2 (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	dtbcb2	{
		UB		dt_dtqsts;				/* Data queue status				*/
} DTQCB2;

/****************************************************************************/
/*			DTQATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	dtqatcb {
		UB		dt_dtqatr;				/* Data queue attribute				*/
} DTQATCB;

/****************************************************************************/
/*			MTXCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mtxcb	{
		TCB		*mx_nexttcb;			/* Next pointer						*/
		TCB		*mx_pretcb;				/* Previous pointer					*/
		UH		mx_locsts;				/* Locking task ID					*/
		PRI		mx_ceilpri;				/* Limit priority of ceiling attr.	*/
		VP		mx_locquen;				/* Locked MTX queue next pointer	*/
		VP		mx_locquep;				/* Locked MTX queue prev. pointer	*/
		UW		mx_quests;				/* Queue status						*/
} MTXCB;

/****************************************************************************/
/*			TLMXCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	tlmxcb	{
		VP		mx_nextloc;				/* Locked MTX queue next pointer	*/
		VP		mx_preloc;				/* Locked MTX queue prev. pointer	*/
} TLMXCB;

/****************************************************************************/
/*			MTXATCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	mtxatcb {
		UB		mx_mtxatr;				/* Mutex attribute					*/
} MTXATCB;

/****************************************************************************/
/*			TSKOVRCB (RAM/hiwrk)											*/
/****************************************************************************/
typedef struct	tskovrcb {
		OVRTIM	ov_ovrtime;				/* Task limit processor time		*/
		OVRTIM	ov_usetime;				/* Task accumulated processor time	*/
		VP		ov_ovrsts;				/* Overrun handler activation status*/
} TSKOVRCB;

/****************************************************************************/
/*			OVRADR (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	ovradr	{
		FP		ov_ovrhdr;				/* Overrun handler address			*/
} OVRADR;

/****************************************************************************/
/*			CACCB (RAM/hiwrk)												*/
/****************************************************************************/
typedef struct	caccb  {
		UW		ca_entnum;				/* CACHE entry number in way		*/
		UW		ca_waynum;				/* CACHE way number					*/
} CACCB;

/****************************************************************************/
/*			MESSAGE (RAM/hiwrk) for Debugging eXtension						*/
/****************************************************************************/
typedef	 struct _message{	   /* Communication message packet				*/
	   UW	   serial_no;	   /* request number							*/
	   FN	   fnc_code;	   /* SVC function code							*/
	   FP	   svc_addr;	   /* SVC address								*/
	   ER	   err_code;	   /* SVC error code							*/
	   UW	   parm1;		   /* SVC parameter 1							*/
	   UW	   parm2;		   /* SVC parameter 2							*/
	   UW	   parm3;		   /* SVC parameter 3							*/
	   UW	   parm4;		   /* SVC parameter 4							*/
	   B	   info[36];	   /* Information area							*/
}MESSAGE;

/****************************************************************************/
/*            STKSZCB (RAM/hiwrk)                                           */
/****************************************************************************/
typedef struct stkszcb  {
       UW      st_stksz;       /* task stack size                           */
} STKSZCB;

/****************************************************************************/
/*			MSGCB (RAM/hiwrk) for Debugging eXtension						*/
/****************************************************************************/
typedef	 struct _msgcb{		   /* Communication message control block packet*/
	   UB	   request_flag;   /* Request flag								*/
	   UB	   result_flag;	   /* Result falg								*/
	   UB	   dmy[2];		   /* (Dummy area)								*/
	   MESSAGE message;		   /* MESSAGE packet							*/
}MSGCB;

/*** SVC trace ********************************/
/*----------- T_TRCCB -----------*/
typedef struct	t_trccb	  {				/* T_TRCCB							*/
			VP			 tr_trbtop;			/* Buffer area top address		*/
			VP			 tr_trbbtm;			/* Buffer area bottom address	*/
			VP			 tr_trbins;			/* Insert pointer				*/
			UW			 tr_trbsts;			/* Trace buffer status			*/
} T_TRCCB;

/*--------- trace entry ---------*/
typedef struct	t_trcent  {				/* Trace entry						*/
			UH			 te_attr;			/* Event attribute				*/
			ID			 te_tskid;			/* tskid						*/
			UW			 te_ltime;			/* System time(lower)			*/
			VW			 te_event;			/* Event information			*/
			VW			 te_par1;			/* SVC parameter1(R4)			*/
			VW			 te_par2;			/* SVC parameter2(R5)			*/
			VW			 te_par3;			/* SVC parameter3(R6)			*/
			VW			 te_par4;			/* SVC parameter4(R7)			*/
			UW			 te_pc;				/* PC(Program counter)			*/
			UW			 te_sr;				/* SR(Status register)			*/
} T_TRCENT;

/*-------- EML trace ------------*/
typedef struct txtrccb{
	VW		tx_trcent;
	VW		tx_objdata[4];
}TXTRCCB;

/****************************************************************************/
/*			SYSMT (ROM/hisetup)												*/
/****************************************************************************/
typedef struct	sysmt	{
		UW		sm_knlmsklvl;	/* Kernel interrupt mask level				*/
		VH		sm_timintvl;	/* Reserved									*/
		UB		sm_uppintnst;	/* Reserved									*/
		UB		sm_lowintnst;	/* Reserved									*/
		ID		sm_maxtskid;	/* Maximum tskid							*/
		ID		sm_ststkid;		/* Maximum tskid using static stack			*/
		PRI		sm_maxtskpri;	/* Maximum tskpri							*/
		ID		sm_maxflgid;	/* Maximum flgid							*/
		ID		sm_maxsemid;	/* Maximum semid							*/
		ID		sm_maxmbxid;	/* Maximum mbxid							*/
		ID		sm_maxmbfid;	/* Maximum mbfid							*/
		ID		sm_maxmplid;	/* Maximum mplid							*/
		ID		sm_maxmpfid;	/* Maximum mpfid							*/
		ID		sm_maxcycno;	/* Maximum cycno							*/
		ID		sm_maxalmno;	/* Maximum almno							*/
		H		sm_maxs_fncd;	/* Maximum s_fncd							*/
		UH		sm_maxiodvn;	/* Maximum iodvn (reserved)					*/
		UH		sm_rsv3;		/* Reserved									*/
		INITSP	*sm_initspp;	/* INITSP table address						*/
		UW		*sm_initblp;	/* INITBL table address						*/
		UW		*sm_iniendp;	/* INIEND table address						*/
		UW		*sm_inihdrp;	/* INIHDR table address						*/
		VW		*sm_trcstkp;	/* Trace Routine stack bottom address		*/
		VW		*sm_knlstkp;	/* Kernel stack bottom address				*/
		SYSCB	*sm_syscbp;		/* SYSCB address							*/
		RDYPRI	*sm_rdyprip;	/* RDYPRI address							*/
		RDYQUE	*sm_rdyquep;	/* RDYQUE address							*/
		TCB		*sm_tcbp;		/* TCB address								*/
		VW		sm_rsv1;		/* rsv1										*/
		TFLCB	*sm_tflcbp;		/* TFLCB address							*/
		VW		*sm_tmquacbp;	/* Reserved									*/
		VW		*sm_quacbp;		/* Reserved									*/
        STKSZCB *sm_stkszcbp;   /* STKSZCB address                          */
		VW		*sm_rsv2;		/* Reserved									*/
		FLGCB	*sm_flgcbp;		/* FLGCB address							*/
		FLGATCB *sm_flgatcbp;	/* FLGATCB address							*/
		SEMCB	*sm_semcbp;		/* SEMCB address							*/
		SEMATCB *sm_sematcbp;	/* SEMATCB address							*/
		MBXCB1	*sm_mbxcb1p;	/* MBXCB1 address							*/
		MBXCB2	*sm_mbxcb2p;	/* MBXCB2 address							*/
		MBXATCB *sm_mbxatcbp;	/* MBXATCB address							*/
		MBFCB1	*sm_mbfcb1p;	/* MBFCB1 address							*/
		MBFCB2	*sm_mbfcb2p;	/* MBFCB2 address							*/
		MBFATCB *sm_mbfatcbp;	/* MBFATCB address							*/
#if ((VTCFG_NEWMPL) == 0)
		MPLCB	*sm_mplcbp;		/* MPLCB address							*/
#else
		VMPLCB	*sm_vmplcbp;	/* VMPLCB address							*/
#endif
		MPLATCB *sm_mplatcbp;	/* MPLATCB address							*/
		MPFCB	*sm_mpfcbp;		/* MPFCB address							*/
		MPFATCB *sm_mpfatcbp;	/* MPFATCB address							*/
		TIMCB	*sm_timcbp;		/* TIMCB address							*/
		CYHCB	*sm_cyhcbp;		/* CYHCB address							*/
		ALHCB	*sm_alhcbp;		/* ALHCB address							*/
		SVCCB	*sm_svccbp;		/* SVCCB address							*/
		CYHCB2	*sm_cyhcb2p;	/* CYHCB2 address							*/
		VW		*sm_stkmplp;	/* Task stack area address					*/
		VW		*sm_mbfmplp;	/* Message buffer area address				*/
		VW		*sm_mplmplp;	/* Variable-size memorypool area address	*/
		VW		*sm_mpfmplp;	/* Fixed-size memorypool area address		*/
		VW		*sm_vctmplp;	/* Vector area(RAM) address					*/
		VW		*sm_nametskp;	/* Reserved									*/
		VW		*sm_namesemp;	/* Reserved									*/
		VW		*sm_nameflgp;	/* Reserved									*/
		VW		*sm_namembxp;	/* Reserved									*/
		VW		*sm_namembfp;	/* Reserved									*/
		VW		*sm_namemplp;	/* Reserved									*/
		VW		*sm_namempfp;	/* Reserved									*/
		VW		*sm_namecycp;	/* Reserved									*/
		VW		*sm_namealmp;	/* Reserved									*/
		INITRC	*sm_initrcp;	/* INITRC table address						*/
		TBACB	*sm_tbacbp;		/* TBACB address							*/
		void	*sm_rsv5;		/* Reserved									*/
		UW		sm_stksize;		/* Dynamic task stack area size				*/
		UW		sm_mbfsize;		/* Message buffer area size					*/
		UW		sm_mplsize;		/* Variable-size memorypool area size		*/
		UW		sm_mpfsize;		/* Fixed-size memorypool size				*/
		VW		sm_expansion1;	/* For expansion-1							*/
		VW		sm_expansion2;	/* For expansion-2							*/
		VW		sm_expansion3;	/* For expansion-3							*/
		VW		sm_expansion4;	/* For expansion-4							*/
		VW		*sm_trpmplp;	/* Trapa area(RAM) address					*/
		VCTCB	*sm_vctcbp;		/* VCTCB address							*/
		UW		sm_pagesz;		/* Reserved									*/
		UW		sm_maxpagcnt;	/* Reserved									*/
		UW		sm_pblcnt;		/* Reserved									*/
		VW		*sm_pplcbp;		/* Reserved									*/
		VW		*sm_pblkcbp;	/* Reserved									*/
		UW		sm_phypagcnt;	/* Reserved									*/
		VW		*sm_phyplcbp;	/* Reserved									*/
		VW		*sm_pagecbp;	/* Reserved									*/
		UW		sm_hipvareatp;	/* Reserved									*/
		VW		*sm_hipvareabp; /* Reserved									*/
		UW		sm_hippareatp;	/* Reserved									*/
		VW		*sm_hippareabp; /* Reserved									*/
		UH		sm_tlbwaynum;	/* Reserved									*/
		UH		sm_tlbentnum;	/* Reserved									*/
		VW		*sm_intstkp;	/* Bottom address of handler stack			*/
		VW		*sm_pagetblixp; /* Reserved									*/
		VW		*sm_pagetblp;	/* Reserved									*/
		UH		sm_cacwaynum;	/* Cache-WAY number of MCU					*/
		UH		sm_cacentnum;	/* Entry number of cache-1WAY				*/
		TSKATCB *sm_tskatcb;	/* TSKATCB address							*/
		VW		*sm_svcatcb;	/* Reserved									*/
		VW		*sm_stdioatcb;	/* Reserved									*/
		UW		*sm_prefinfp;	/* Setup side PREF information table		*/
		UW		*sm_inihdr_s_p; /* system INIHDR table address				*/
		UW		*sm_mtdrdyp;	/* mtdrdy address							*/
		UW		*sm_txmodep;	/* txmode address							*/
		TXTRCCB	*sm_txtrccbp;	/* txtrccb address							*/
		UH		 sm_dxquecnt;	/* DX queue count							*/
		UH		 sm_dxcyctim;	/* daemon cyclic time						*/
		MSGCB	*sm_dbgmemp;	/* DX communication memory					*/
		VW		*sm_tmrhdrstkp; /* Bottom address of timer handler stack	*/
		TEXCB	*sm_texcbp;		/* TEXCB address							*/
		TEXATCB *sm_texatcbp;	/* TEXATCB address							*/
		ID		sm_maxdtqid;	/* Maximum dtqid							*/
		ID		sm_maxmtxid;	/* Maximum mtxid							*/
		DTQCB1	*sm_dtqcb1p;	/* DTQCB1 address							*/
		DTQCB2	*sm_dtqcb2p;	/* DTQCB2 address							*/
		DTQATCB *sm_dtqatcbp;	/* DTQATCB address							*/
		VW		*sm_dtqmplp;	/* Data queue area address					*/
		UW		sm_dtqsize;		/* Data queue area size						*/
		MTXCB	*sm_mtxcbp;		/* MTXCB address							*/
		MTXATCB *sm_mtxatcbp;	/* MTXATCB address							*/
		TLMXCB	*sm_tlmxcbp;	/* TLMXCB address							*/
		TSKOVRCB *sm_tskovrcbp; /* TSKOVRCB address							*/
		OVRADR	*sm_ovradrp;	/* OVRADR address							*/
		UW		sm_ticnume;		/* tic numerator							*/
		UW		sm_ticdeno;		/* tic denominator							*/
		PRI		sm_maxmpri;		/* Maximum message priority					*/
		UH		sm_rsv6;		/* Reserved									*/
		CACCB	*sm_caccbp;		/* CACCB address							*/
		TMU_DRVMT *sm_tmrdrvmtp; /* Optimized timer manegement CB			*/
#ifdef _SH4ALDSP
        UW      sm_icsize;      /* instruction Cache size                   */
        UW      sm_ocsize;      /* operand Cache size                       */
#endif
} SYSMT;

#pragma unpack
#endif
