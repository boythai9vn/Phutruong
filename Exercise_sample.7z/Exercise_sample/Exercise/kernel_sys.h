/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_sys.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_SYS_H
#define _HIOS_KERNEL_SYS_H

/****************************************************************************/
/*			Kernel identification information								*/
/****************************************************************************/
#define HI7000_4		7000			/* kernel = HI7000/4				*/
#define HI7700_4		7700			/* kernel = HI7700/4				*/
#define HI7750_4		7750			/* kernel = HI7750/4				*/

#define hi_hios			HI7700_4		/* This kernel = HI7700/4			*/

/****************************************************************************/
/*			Constant definition												*/
/****************************************************************************/
/*-------------------------------- Common ----------------------------------*/
#define USE				TRUE			/* Use								*/
#define NOTUSE			FALSE			/* Not use							*/
#define RESERVE			0				/* Reserved							*/
#define IGNORE			0				/* Ignore							*/
#define NADR			(-1)			/* invalid address					*/
#define DUMMY			NADR			/* Dummy address					*/
#define NO_TRACE		0x00000000		/* NO  trace						*/
#define TARGET_TRACE	0x00000001		/* KNL trace						*/
#define EML_TRACE		0x00000002		/* DX  trace						*/
#define ACTION			0x00000004		/* DX SVC function					*/

/*--------------------------- hi_quick -------------------------------------*/
#define ALL				0x00000001		/* All (hi_quick)					*/
#define NO				0x80000000		/* No specify (hi_quick)			*/

/*-------------------- Trace routine stack size ----------------------------*/
#define TRCSTKSZ		48				/* Trace routine stack size (Kernel)*/

/*-------------------------------- Others ----------------------------------*/
#define SR_MD			0x40000000		/* Kernel SR data					*/

#define MD_BIT	   SR_MD				/* MD bit							*/
#define RB_BIT	   0x20000000			/* RB bit							*/
#define BL_BIT	   0x10000000			/* BL bit							*/
#define FD_BIT	   0x00008000			/* FD bit							*/
#define INTDWN_SR  (MD_BIT | BL_BIT | (SR_IMS00 << 4)) /* Sysdwn SR			*/
#define DEFAULT_SR (MD_BIT | (SR_IMS00 << 4))	 /* Default SR				*/
#define HIKNL_SR   (MD_BIT | (SR_IMS00 << 4))	 /* TRAPA #16 - #31 SR		*/
#define UNDEF_SR   (MD_BIT | (SR_IMS00 << 4))	 /* Undefined SR(rte)		*/
#define TLBMIS_SR  (MD_BIT | BL_BIT | (SR_IMS00 << 4)) /* tlb_mis SR		*/

/*---------------------- Vector Table structure ----------------------------*/
#pragma pack 4
typedef struct t_vctent {				/* vcttbl define packet				*/
			FP			 t_handler;			/* handler routine address		*/
			UINT		 t_sr;				/* handler routine SR			*/
} T_VCTENT;

#pragma unpack
/****************************************************************************/
/*			Macro definition												*/
/****************************************************************************/
#define jsvcdef(a,b,c)((a)?(select(hi_parchk,(FP)(b),(FP)(c))):(FP)_kernel_er_nospt)
#define funcdef(a, b)	((a) ? (FP)(b) : (FP)NADR)
#define select(a,b,c)	((a) ? (b) : (c))

#include "kernel_opttmr_tbl.h"
#include "kernel_dspstby_tbl.h"

#endif
